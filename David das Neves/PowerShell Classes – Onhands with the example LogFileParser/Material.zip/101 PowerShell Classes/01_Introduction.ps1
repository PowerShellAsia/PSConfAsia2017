#TimeBomb
Write-Host "You have 20 seconds left" -ForegroundColor Yellow
Start-Sleep -Seconds 20


#Class with constructor
class Returner
{ 
  #Constructor without values
  Returner()
  {}

  #method 
  [string] returnSomething()
  {
    return "something"
  }
}

#Instanciate
$instance = [Returner]::new()

#Instance
$instance

#Method
$instance.
$instance.returnSomething() 

#Static Class
[System.Environment]::OSVersion


############################################################################

#Class with constructor
class SecretStorer
{ 
  #Constructor without values
  SecretStorer()
  {
  }

  #Constructor with values
  SecretStorer([string]$secretString, [int]$secretInt)
  {
    
    $this.secretInt = $secretInt
    $this.secretString = $secretString
  }

  #Property
  [string]$secretString

   #Property
  [int]$secretInt

  #method 
  [string] returnSomething()
  {
    return "SecretString: $($this.secretString) $([System.Environment]::NewLine)SecretInt: $($this.secretInt)"
  }

  #method for string
  storeSecret([string]$secret)
  {
    $this.secretString = $secret
  }

  #Meth - overloaded for integer
  storeSecret([int]$secret)
  {
   $this.secretInt = $secret
  }
}

############################################################################

#Instanciate
$instance = [SecretStorer]::new()

#Instance
$instance

#Instanciate
$instance = [SecretStorer]::new('PSConfAsia2017',1337)

#Instance
$instance

#Properties
$instance.secretInt
$instance.secretString

#Properties - types
($instance.secretInt).GetType()
($instance.secretString).GetType()

#Store
$instance.storeSecret('PSConfAsia is awesome!')

#take a look at the properties
$instance.returnSomething()

#Store
$instance.storeSecret(1338)

#take a look at the properties
$instance.returnSomething()


$instance.toString()

############################################################################

#Class with constructor
class SecretStorerv2 : SecretStorer
{ 
  #Constructor without values
  SecretStorerv2(): base()
  {  }

  #Constructor with values
  SecretStorerv2([string]$secretString, [int]$secretInt): base([string]$secretString, [int]$secretInt)
  {  }

  #Meth - overloaded for integer
  [string] ToString()
  {
    return [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String('QgBhAG0AIQAgAEQAYQB2AGkAZAAgAGkAcwAgAGEAdwBlAHMAbwBtAGUAIQA='))
  }
}

############################################################################

$instance = [SecretStorerv2]::new()

$instance.returnSomething()

#ToString()
"$instance"












































$Text = �Bam! David is awesome!�
$Bytes = [System.Text.Encoding]::Unicode.GetBytes($Text)
$EncodedText =[Convert]::ToBase64String($Bytes)
$EncodedText
#The result is this base64 encoded text:
#VABoAGkAcwAgAGkAcwAgAGEAIABzAGUAYwByAGUAdAAgAGEAbgBkACAAcwBoAG8AdQBsAGQAIABiAGUAIABoAGkAZABlAG4A
#Decoding:
#Decoding the base64 encoded blob using PowerShell is simple.
$EncodedText = �QgBhAG0AIQAgAEQAYQB2AGkAZAAgAGkAcwAgAGEAdwBlAHMAbwBtAGUAIQA=�
$DecodedText = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($EncodedText))
$DecodedText

[System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String('QgBhAG0AIQAgAEQAYQB2AGkAZAAgAGkAcwAgAGEAdwBlAHMAbwBtAGUAIQA='))
