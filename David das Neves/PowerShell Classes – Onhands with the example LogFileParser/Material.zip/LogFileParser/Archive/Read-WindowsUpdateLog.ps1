Function Read-WindowsUpdateLog {
  Param (
    [Parameter(MAndatory=$false)]
    [ValidateScript({
    
      test-Path $_
    })]
    [string]$Path = (Join-Path -path $Env:windir -ChildPath WindowsUpdate.log),
    [PArameter(Mandatory=$false)][datetime]$Date,
    [Switch]$GetInstalledUpdates
  )
  


  $RawContent = gc -path $Path -ReadCount 0

  #as described here https://support.microsoft.com/en-us/kb/902093
  
  $Pattern = '(?<Date>\d{4}-\d{2}-\d{2})\t(?<Time>\d{2}:\d{2}:\d{2}:\d{3})\s+(?<PID>\d{3,4})\s(?<TID>.{3,4})\s(?<Agent>\w{0,})\s(?<Message>.*$)'  
$objects = @()
  foreach ($line in $RawContent){
  
    if ($line -match $Pattern){
      $hash = [Ordered]@{}
      $hash.Date = $Matches.Date
      $hash.Time = $Matches.Time
      $hash.pid = $Matches.PID
      $hash.tid = $Matches.tid
      $hash.agent = $Matches.Agent
      $hash.Message = $Matches.Message
  
      $obj = New-Object -TypeName psObject -Property $hash
      $objects += $obj
    }
  }

if ($GetInstalledUpdates){
  
  
  $kbobjects = @()
    foreach ($o in $objects){
        $Pattern = 'Title\s=\s(?<UpdateName>.{1,})'
        If ($o.Message -match $Pattern){
          $h = [Ordered]@{}
          $h.Date = $o.date
          $h.time = $o.time
          $h.UpdateName = $Matches.UpdateName
      
          $kbobj = New-Object psobject -Property $h
          $kbobjects += $kbobj
        }
    }
        return $kbobjects | Sort-Object date
    }

  If(!$date){
  
    write-verbose "Returning non sorted entries"
    return $objects
  
  }Else{
    $filteredDate = get-date $date -UFormat %Y-%m-%d
    Write-Verbose "REturning sorted objects on date $($date)"
    $SortedObjects = ($objects | Group-Object date | ? {$_.name -eq $filteredDate}).Group | sort-object time #| select date,time,message | Sort-Object time
    return $SortedObjects
  }
  
  
}



