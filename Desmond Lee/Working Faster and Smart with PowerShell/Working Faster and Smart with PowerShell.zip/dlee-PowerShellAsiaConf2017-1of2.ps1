﻿################################################################################
# Copyright (c) 201x-2017 leedesmond.com
# All Rights Reserved. Use at your own risk and responsibility.
#
# https://www.leedesmond.com/2017/07/speaker-powershell-conference-2017-asia-singapore-26-28-oct-2017/
# dlee-PowerShellAsiaConf2017-1of2.ps1
# Version 1.00
#
################################################################################

#--------------------------------------------------------------------------
#region swap

$a = 1
$b = 2
$a; $b

$c = $a
$a = $b
$b = $c
$a; $b

#endregion swap
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
#region null object

Get-Process | Select-Object -Property Company

$gps = Get-Process
$gps.Count
$gps | Select-Object -Property Company
        
$gps | select -prop Company | Where-Object company -ne " "

$s = ""
$gps | select -prop Company | Where-Object company -ne $s

"" -eq $null
#False

$s = $null
$gps | select       Company | where company -ne $null

$gps | <# select Company | #> % { $_.GetType() } | Format-Table -AutoSize


#endregion null object
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
#region WMICIM

Get-WmiObject -Class Win32_OperatingSystem | Select-Object LastBootUpTime

Get-WmiObject -Class Win32_OperatingSystem |
    select @{L='LastBootUpTime'; E={$_.ConvertToDateTime($_.LastBootUpTime)}}

#endregion WMICIM
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
#region cmdlet parameters

cd $env:windir
Get-ChildItem *.cpl -Recurse    #-Path
        
help dir -ShowWindow
Trace-Command -Expression { Get-ChildItem *.cpl -Recurse } ParameterBinding -PSHost

$ErrorActionPreference
#$ErrorActionPreference = "Continue"

dir *.cpl -Recurse -ErrorAction:SilentlyContinue
    
#!
##requires -version 5.0    
dir *.cpl -re -ea:SilentlyContinue -DEPTH 1

help dir -ShowWindow

dir -Path . *.cpl -re -ea:SilentlyContinue -Depth 1

#endregion cmdlet parameters
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
#region Operators -in -contain
          
$fruits = "apple","orange","pear","mango"
$myfruit = "papaya"

$myfruit -eq "apple"
$myfruit -eq "apple" -or $myfruit -eq "orange"
$myfruit -eq "pear"  -or $myfruit -eq "apple"  -or $myfruit -eq "orange"
$myfruit -eq "mango" -or $myfruit -eq "orange" -or $myfruit -eq "apple" -or $myfruit -eq "pear"




#endregion Operators -in -contains
#--------------------------------------------------------------------------    

#--------------------------------------------------------------------------
#region Operators -match

$myfruit = "apple"       
$fruits = "apple","orange","pear","mango"

$myfruit -match $fruits
$matches

$matches[0]
$matches.GetType()

#!
$fruits = "apple,orange,pear,mango"

$myfruit -match $fruits
$matches

#endregion Operators -match
#--------------------------------------------------------------------------
    
#--------------------------------------------------------------------------
#region array - find item

$fruits = "durian","guava","kumquat","pomelo","lychee",
    "longan","dragonfruit","mangosteen","rambutan","bayberry"
#$fruits.count  #10

$myfruit = "lychee"

for ($i = 0; $i -lt $fruits.count; $i++)
{
    if ($fruits[$i] -eq $myfruit)
    {
        "found '$($fruits[$i])' at index $i"
        break;
    }
}
#####
$j = 0
foreach ($fruit in $fruits)
{
    if ($fruit -eq $myfruit)
    {
        "found '$($fruits[$j])' at index $j"
        break;
    }
    $j++
}

#endregion array - find item
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
#region array - operations

$arr = @()
1..1000 | % { $arr += $_ }
$arr.IsFixedSize
#True
#$arr; $arr.count

#save to a new variable
$arr2Array = $arr
$arr2Array.count

#check value stored at this array location
$arr[5]
#6

#check value stored at this copied array location
$arr2Array[5]
#6

#modify value stored at this copied array location
$arr2Array[5] = 99
$arr2Array[5]
#99

#original value at source array also affected
$arr[5]
#6


#endregion array - operations
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
#region regex

$dn = "CN=dlee,OU=IT,OU=Corp,DC=leedesmond,DC=com"

#non regex method
$idx = $($dn).IndexOf(",")
$dn.SubString(0,$idx).SubString(3) 
#dlee

#endregion regex
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
#region Advanced functions

$min = 1; $max = 5
function fb($i)
{
	#check if $i lies between 
	#the given range   
	if ($i -ge $min -and $i -le $max) 
	{
		"'$i' is within range"
	}
	else 
	{
		"'$i' is out of range"
	}
}

#endregion Advanced functions
#--------------------------------------------------------------------------


