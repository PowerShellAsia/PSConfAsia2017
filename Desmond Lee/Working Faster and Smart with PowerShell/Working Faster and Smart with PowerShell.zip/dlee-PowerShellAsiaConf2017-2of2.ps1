﻿################################################################################
# Copyright (c) 201x-2017 leedesmond.com
# All Rights Reserved. Use at your own risk and responsibility.
#
# https://www.leedesmond.com/2017/07/speaker-powershell-conference-2017-asia-singapore-26-28-oct-2017/
# dlee-PowerShellAsiaConf2017-2of2.ps1
# Version 1.00
#
################################################################################

#--------------------------------------------------------------------------
#region swap

$a = 1
$b = 2
$a; $b

$a, $b = $b, $a
$a; $b



#endregion swap
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
#region null object

Get-Process | Select-Object -Property Company

$gps = Get-Process

$gps | select Company | ? company

$gps | ? Company      | select company

$gps.Company

#!
gps.Company

##requires -version 3.0
(gps).company





#endregion null object
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
#region WMICIM

##requires -version 3.0
Get-CimInstance -Class Win32_OperatingSystem | select LastBootUpTime

Get-Command -Noun cim*

#endregion WMICIM
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
#region cmdlet parameters

cd $env:windir

##requires -version 5.0    
dir -Path . -Filter *.cpl -Recurse -ea:SilentlyContinue -Depth 1
    
dir -Path . -Filter  *.cpl -Recurse -ea:SilentlyContinue -Depth 1  | ? { $_ -like "m*" }    
dir -Path . -Filter m*.cpl -Recurse -ea:SilentlyContinue -Depth 1

#!
dir -Path $env:windir -Filter  *.cpl -Recurse -ea:SilentlyContinue -Depth 1 -Include m*

dir -Path . -Filter  *.cpl -Recurse -ea:SilentlyContinue -Include m* -Depth 1 







#endregion cmdlet parameters
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
#region Operators -in -contain
          
$fruits = "apple","orange","pear","mango"
$myfruit = "papaya"

##requires -version 3.0
$myfruit -in $fruits      
$fruits -contains $myfruit

$myfruit = "aPpLe"
$myfruit -in $fruits      
$fruits -contains $myfruit

#endregion Operators -in -contains
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------  
#region Operators -match

$myfruit = "apple"        
$fruits = "apple|orange|pear|mango"

$myfruit -match $fruits
$matches

$matches[0]
$matches.GetType()







#endregion Operators -match
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
#region array - find item

$fruits = "durian","guava","kumquat","pomelo","lychee",
    "longan","dragonfruit","mangosteen","rambutan","bayberry"
#$fruits.count  #10

$myfruit = "lychee"
        
if ($myfruit -in $fruits)
#if ($fruits -contains $myfruit)
{
    $k = [array]::IndexOf($fruits,$myfruit)
    "found '$($fruits[$k])' at index $k"
}

###
if ( ($k = [array]::IndexOf($fruits,$myfruit)) -ne -1)
{
    "found '$($fruits[$k])' at index $k"
}








#endregion array - find item
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
#region array - operations

$arr1 = New-Object System.Collections.ArrayList
$arr1.count
#0

#adds 1000 elements to the ArrayList
#[void] or pipe to Out-Null suppresses echo
1..1000 | % { [void]$arr1.Add($_) }
$arr1.count
#1000
$arr1.IsFixedSize
#False

#adds another 1000 elements at one go
$arr1.AddRange(1001..2000)


###
$arr2 = New-Object System.Collections.ArrayList
$arr2.GetType()
$arr2.AddRange(1..1000)
#$arr2; $arr2.count


#convert from ArrayList to a regular array
#and save to a new variable
$arr2Array = $arr2.ToArray()
$arr2Array.GetType()

$arr2Array.count
#1000

#check value stored at this array location
$arr2Array[5]
#6

#check value stored at this ArrayList location
$arr2[5]
#6

#modify value stored at this array location
$arr2Array[5] = 99
$arr2Array[5]
#99

#original value at source ArrayList untouched
$arr2[5]
#6


###
#addition and removal operations on ArrayList items
$arr3 = New-Object System.Collections.ArrayList        
$arr3.AddRange(1..10)
$arr3.count

$arr3.Remove(3)           #item with the value 3
$arr3.count
$arr3

$arr3.RemoveAt(3)         #item at array index 3
$arr3.count
$arr3

$arr3.RemoveRange(2,5)    #starting from index 2 remove 5 items
$arr3.count
$arr3

$arr3.GetType()
$arr3.ToArray().GetType()

$arr3.Clear()
$arr3.count


###
#creates an ArrayList from a regular array
$fruits = "durian","guava","kumquat","pomelo","lychee",
    "longan","dragonfruit","mangosteen","rambutan","bayberry"

[System.Collections.ArrayList]$arr4 = $fruits
$arr4
$arr4.GetType()
$arr4.Count
        

###
$fruits
$fruits.Count

$fruits -ne "longan"        

#creates a new array without specific item(s)
$fruits1 = $fruits -ne "longan"
$fruits1.Count
$fruits1

        
#endregion array - operations
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
#region regex

$dn = "CN=dlee,OU=IT,OU=Corp,DC=leedesmond,DC=com"

$m = [regex]"CN=(.+)"
$dn -match $m
#True 

$matches
#Name Value                                     
#---- -----                                     
#1    dlee,OU=IT,OU=Corp,DC=leedesmond,DC=com   
#0    CN=dlee,OU=IT,OU=Corp,DC=leedesmond,DC=com


#excludes comma and trailing text
$m = [regex]"CN=(.[^,]+)"
$dn -match $m

#matching first group (per parenthesis)
$matches[1] 
#dlee 


#endregion regex
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
#region Advanced functions
#Get-Help about_Functions_Advanced*

function fb
    {
        [CmdletBinding()]
        param(            
            [ValidateRange(1,5)]
            $i            
        )

        "'$i' is within range"        
    }

#error handling
try { fb -i 0 } catch { "Out of range!" }


###
function foobar($mfl, $sbb)
{
    $mfl | % {
        try   { 
            if (&$sbb $PSItem) { "'$_' is my colour.`n" } 
			        }
        catch { 
            "Not my colour!`n($_.Exception.Message)`n" 
			        } 
    }
}
#
$sb = { param([ValidateSet("red","green","blue")]$flist) $flist }

$myflist = "pink","blue","green"
foobar $myflist $sb


#endregion Advanced functions
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
#region enum

    ##requires -version 5.0
    enum tl { red; orange; green }

    #!
    $tl
    [tl]

    [tl].count
    [tl].GetType() | ft -au

    [tl] | gm

    [tl].GetEnumNames()
    [tl].GetEnumValues()
    [tl].GetEnumValues().value__

   
    [tl]::red
    [tl]::red.value__

    [tl] | gm -Static
    

    ###
    function dieAmpel([tl]$status) { $status }

    #!
    dieAmpel [tl]::orange

    dieAmpel ([tl]::orange)
    dieAmpel 2

    #!
    dieAmpel 5

    dieAmpel "green"
    dieAmpel green
    dieAmpel grün


    #####
    enum tl1 { red = 3; orange = 6; green = 9; invalid = 0 }
    [tl1].GetEnumNames()   #.GetEnumerator()
    [tl1].GetEnumValues().value__
    
    [enum]::GetValues([tl1])
    [enum]::GetValues([tl1]).value__

    [enum]::GetValues([type]"tl1")
    [enum]::GetValues([type]"tl1").value__

    #!
    function testenum([enum]$tls)
    {
        switch ($tls) {
            { [tl1]::green   }{ "g" ; <# break;#> }
            { [tl1]::invalid }{ "i" ; <# break;#> }
            { [tl1]::red     }{ "r" ; <# break;#> }
            { [tl1]::orange  }{ "o" ; <# break;#> }        
        }
    }
    #
    testenum ([tl1]::red)  #.value__


    #####
    enum tl2 { red = 3; orange = 6; green = 9; invalid = 0 }
    #
    function testenum1([enum]$tls)
    {
        switch ($tls) {
            { [tl2]::green    }{ "g" ; break; }
            { [tl2]::invalid  }{ "i" ; break; }
            { [tl2]::red      }{ "r" ; break; }
            { [tl2]::orange   }{ "o" ; break; }        
        }
    }
    #
    #!
    testenum1 ([tl2]::red) 

    #$_ -eq
    
    
    ###
    New-Variable -Name red    -Value 0 -Option Constant #ReadOnly
    New-Variable -Name orange -Value 1 -Option Constant
    New-Variable -Name green  -Value 2 -Option Constant

    $red
    #!
    $red = 3
    
    [enum] | Get-Member

#endregion enum
#--------------------------------------------------------------------------


#--------------------------------------------------------------------------
#region Bug-buster

    #Set-StrictMode -Version Latest
    if (Test-Path variable:\tvar) { Remove-Item variable:\tvar }
    
    function SayHi
    {
        if ($tvar -eq "Bonjour") { "Hello!" }
        else { "<Silence>" }
    }

    #$tvar = "Bonjour"
    SayHi


    if (Test-Path variable:\tvar) { Remove-Item variable:\tvar }
    Set-StrictMode -Off

#endregion Bug-buster
#--------------------------------------------------------------------------



#--------------------------------------------------------------------------
#region Measurement

$dateStart = Get-Date

#do something

$dateEnd = Get-Date
$dateEnd - $dateStart


###
Measure-Command -Expression { 
    gps | ? company | select name, object }


###
$stopwatch = [system.diagnostics.stopwatch]::StartNew()
#$stopwatch.IsRunning

foreach ($num in 1..1000) { $num }

$stopwatch.Stop()
$stopwatch.Elapsed

#$stopwatch.Start()

 
#endregion Measurement
#--------------------------------------------------------------------------