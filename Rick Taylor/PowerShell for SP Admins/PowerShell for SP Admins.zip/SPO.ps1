﻿$adminUPN="rick.taylor@zaactdev.com" #the full email address of a SharePoint administrator account, example: jdoe@contosotoycompany.onmicrosoft.com
$orgName="zaactdev"
$userCredential = Get-Credential -UserName $adminUPN -Message "Type the password."
Connect-SPOService -Url "https://$orgName-admin.sharepoint.com" -Credential $userCredential