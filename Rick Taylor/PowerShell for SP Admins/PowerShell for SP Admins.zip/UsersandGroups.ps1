﻿#Next line reads from a .csv file and creates the site collections in the list in the file
Import-Csv "C:\Users\Rick Taylor\OneDrive\CONFERENCES\PowerShell Asia 2017\DEMO\SiteCollections.csv" | ForEach-Object {New-SPOSite -Owner $_.Owner -StorageQuota $_.StorageQuota -Url $_.Url -NoWait -ResourceQuota $_.ResourceQuota -Template $_.Template -TimeZoneID $_.TimeZoneID -Title $_.Name};
#Next line shows which site collections were created
Get-SPOSite -Detailed | Format-Table -AutoSize
#Next line reads from a .csv file and creates SharePoint Groups and assigns permissions
Import-Csv "C:\Users\Rick Taylor\OneDrive\CONFERENCES\PowerShell Asia 2017\DEMO\GroupsAndPerms.csv" | ForEach-Object {New-SPOSiteGroup -Group $_.Group -PermissionLevels $_.PermissionLevels -Site $_.Site};
#Next line reads from a .csv file and adds the users from the list in the file to the SharePoint groups created in the previous command (NOTE: users MUST ALREADY EXIST)
Import-Csv "C:\Users\Rick Taylor\OneDrive\CONFERENCES\PowerShell Asia 2017\DEMO\Users.csv" | where {Add-SPOUser -Group $_.Group -LoginName $_.LoginName -Site $_.Site}