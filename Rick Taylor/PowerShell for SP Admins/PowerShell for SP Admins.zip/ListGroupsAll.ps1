﻿# command set that lists the groups, and all the group memberships, for all of your SharePoint Online sites.
$sw = [Diagnostics.Stopwatch]::StartNew()
$x = Get-SPOSite

foreach ($y in $x)
    {
        Write-Host $y.Url -ForegroundColor "Yellow"
        $z = Get-SPOSiteGroup -Site $y.Url
        foreach ($a in $z)
            {
                 $b = Get-SPOSiteGroup -Site $y.Url -Group $a.Title 
                 Write-Host $b.Title -ForegroundColor "Cyan"
                 $b | Select-Object -ExpandProperty Users
                 Write-Host
            }
    }
$sw.Stop()
$elapsedSeconds = [Math]::Round($sw.Elapsed.Seconds, 0)
$elapsedMinutes = [Math]::Round($sw.Elapsed.Minutes, 0)
$elapsedHours = [Math]::Round($sw.Elapsed.Hours, 0)