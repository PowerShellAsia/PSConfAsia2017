﻿Write-Warning 'Use F8';Break

######################
#    RTFM EXPRESS    #  
######################  

# Q: How Do You Eat an Elephant?
# A: Take a Small Bite. Chew & Swallow. Repeat...

##############################################################################
#region #### Basics

# First things first...
Invoke-DemoGod


############################################## Too Basic 

# Positional Arguments in $Args
function DoStuff{
    <# Code Goes Here #>
    $Args
    # $Args[0]
    # $Args[1]
    # ...
    }

# Ok
DoStuff
DoStuff HelloWorld
DoStuff HelloWorld 123
DoStuff Hello World 1,2,3

#  /!\ Danger:
#  Function -> Accepts any input 
#  Dev      -> Need code++ for Input handling
#  User     -> Doesn't know what to do
#  -> Ok for internal but not tool itself. 





############################################### Basic Recipe
Help about_Functions
Help about_Parameters


## STEP 1

# Use Verb-Noun for Function name     -> /!\ Official Verbs for 'Official' Tools (Get-Verb)
# Add Alias for Cmdline users         -> Ninja friendly
# Add Named Parameters                -> Call value by its name

Function Verb-Noun{
    [Alias('vno')]
    Param(
		[Parameter()]$ParamOne,
		[Parameter()]$ParamTwo
		)
    <# Code Goes Here #>
    $PSBoundParameters
    }

# Ok
Verb-Noun
Verb-Noun -ParamOne 'HelloWorld'
Verb-Noun -ParamOne 'HelloWorld' -Paramtwo 23
Verb-Noun -ParamOne 23 -Paramtwo 'HelloWorld'
# Error
Verb-Noun -ParamOne 'HelloWorld' -Paramtwo 23 -ParamThree Fail




### STEP 2

# Add Help <------------------------------ /!\ IMPORTANT. DO IT. /!\
# Example here is strict minimum 
# (see full function snippet [ctrl-J]) 

<#
.Synopsis
   Do Some Stuff
.DESCRIPTION
   Does some cool stuff... Really. 
.EXAMPLE
   Verb-Noun -ParamOne 'HelloWorld'
   Runs Verb-Noun with HelloWorld as ParamOne value.
#>
Function Verb-Noun{
    [Alias('vno')]
    Param(
		# Description for ParamOne
        [Parameter()]$ParamOne,
        # Description for ParamTwo
		[Parameter()]$ParamTwo
		)
    <# Code Goes Here #>
    $PSBoundParameters
    }


# Help
Get-Help Verb-Noun
Help Verb-Noun -full
Help Verb-Noun -Examples
Help Verb-Noun -ShowWindow

# Help on writing help
Help about_Comment_Based_Help



### STEP 3

## Specify Param Type
## Specify if Param Mandatory

<#
.Synopsis
   Do Some Stuff
.DESCRIPTION
   Does some cool stuff... Really. 
.EXAMPLE
   Verb-Noun -ParamOne 'HelloWorld'
   Runs Verb-Noun with HelloWorld as ParamOne value.
#>
Function Verb-Noun{
    [Alias('vno')]
    Param(
		# Param One Description
		[Parameter(Mandatory=$true)][String]$ParamOne,
 		# Param Two Description
		[Parameter()][int]$ParamTwo
		)
    <# Code Goes Here #>
    $PSBoundParameters
    }

# OK
Verb-Noun -ParamOne 'HelloWorld'
Verb-Noun -ParamOne 'HelloWorld' -Paramtwo 23
# Error
Verb-Noun -ParamOne 23 -Paramtwo 'HelloWorld'
Verb-Noun


# Voila! Basics done...



############################################# OutputType
# = Cherry on the Cake!
Help about_Functions_OutputTypeAttribute


function Demo-OuputType{
    [Alias('OuputType')]
    [OutputType([String])]
    Param()
    'HelloWorld'
    }

# Tab complete properties after pipe
OuputType | ?  <#TAB#>
# test with DateTime|PSCredential|...
# Sweeeet!

# Note: /!\ Does not cast to type 



# But there is waaaay more...

#endregion ###


##############################################################################
#region #### Cmdlet Bindings

############################################## CmdletBindings
# Bundle of extra features. For Free!!
Help about_CommonParameters
Help about_Functions_CmdletBindingAttribute
<#
[CmdletBinding()] Gives Access to 'Basic' Bundle of extra features:  (CommonParameters)
    - Verbose
    - Debug
    - ErrorAction
    - Warning Action
    - InformationAction
    - ErrorVariable
    - InformationVariable
    - OutVariable
    - OutBuffer
    - PipelineVariable
#>

## No Cmdlet Bindings
function Demo-NoBindings{
    [Alias('NoBindings')]
    Param()
    <# Code Goes Here #>
    }

# Check Intellisense
NoBindings <#DASH#>


## With Cmdlet Bindings
function Demo-WithBindings{
    [CmdletBinding()]
    [Alias('WithBindings')]
    Param()
    <# Code Goes Here #>
    }

# Check Intellisense
WithBindings   <#DASH#>

# Note: Declaring a parameter with [Parameter()] also implicitly enables [CmdletBinding()]


############################################## Verbose
function Demo-VerboseExample{
    [CmdletBinding()]
    [Alias('VerboseExample')]
    Param()
    Write-Verbose 'This is my verbose message'
    #(iwr http://google.com).statuscode
    }

VerboseExample
VerboseExample -verbose


############################################## Error Action
# (Same for Warning & Information)

function Demo-ThisError{
    [CmdletBinding()]
    [Alias('ErrorExample')]
    Param()
    ThisIsAnError
    }

# Get this error
ErrorExample
# Captured in $error variable
$Error[0].Exception


# Silent Error
function Demo-ErrorSilent{
    [CmdletBinding()]
    [Alias('ErrorSilent')]
    Param()
    ThatIsAnError
    }

# Example ea: Silent 
ErrorSilent -ErrorAction SilentlyContinue
# But still Captured
$Error[0].Exception

ErrorSilent -ErrorAction SilentlyContinue -ErrorVariable MyError
$MyError.Exception

# Note: Works same way for Warning & Info

# See 
Help about_CommonParameters

# (Advanced kungFu: Check PipeliveVariable Example)


## Can Declare More...
Help about_Functions_CmdletBindingAttribute
<#
Can specify more Cmdlet Binding Attributes
- DefaultParameterSetName <------------------- Keeping for later
- HelpURI
- SupportsPaging
- SupportsShouldProcess
- ConfirmImpact
- PositionalBinding
#>



############################################## HelpURI

<#
.Synopsis
   Synopsis
.DESCRIPTION
   Long Description 
.EXAMPLE
   Example
   Example Description
#>
function Demo-HelpURI{
    [CmdletBinding(HelpURI='https://youtu.be/sdeMkRCsbN0?t=5s')]
    [Alias('HelpURI')]
    Param()
    }

Get-Help Demo-HelpURI
Help HelpURI -Online





############################################## SupportsPaging
function Demo-SupportsPaging{
    [CmdletBinding(SupportsPaging=$true)]
    [Alias('SupportsPaging')]
    Param()
    Process{$PSCmdlet.PagingParameters}
    }

# Check Intelisense
SupportsPaging  <#DASH#>


# Example
function Get-Numbers{
    [CmdletBinding(SupportsPaging = $true)]
    param(
        [Parameter(Mandatory=$true)][Int]$Max
        )
    $FirstNumber = [Math]::Min($PSCmdlet.PagingParameters.Skip, $Max)
    $LastNumber  = [Math]::Min($PSCmdlet.PagingParameters.First + $FirstNumber - 1, $Max)
    if ($PSCmdlet.PagingParameters.IncludeTotalCount){
        $TotalCountAccuracy = 1.0
        $TotalCount = $PSCmdlet.PagingParameters.NewTotalCount(100, $TotalCountAccuracy)
        Write-Output $TotalCount
        }
    $FirstNumber .. $LastNumber | Write-Output
    }

Get-Numbers 123 -Skip 111
Get-Numbers 123 -First 7



############################################## SupportsShouldProcess
Function Demo-ShouldProcess{
    [CmdletBinding(SupportsShouldProcess=$true)]
    [Alias('ShouldProcess')]
    Param(
        [Parameter(Mandatory=$true)]$Target
        )
    If($pscmdlet.ShouldProcess($Target, "First Stuff")){
        <#Some Code Goes Here#>
        'Hello'
        }
    If($pscmdlet.ShouldProcess($Target, "Second Stuff")){
        <#More Code Goes Here#>
        'World'
        }
    }

# Normal
ShouldProcess Bob
# Simulates action
ShouldProcess Bob -WhatIf
# Asks for confirm
ShouldProcess Bob -Confirm






############################################## ConfirmImpact
function Demo-ConfirmImpact{
    [CmdletBinding(ConfirmImpact='Medium')]
    [Alias('ConfirmImpact')]
    Param()
    If($pscmdlet.ShouldProcess('My Target','Doing My Stuff')){
        <#Some Code Goes Here#>
        'HelloWorld'
        }
    }

$ConfirmPreference
ConfirmImpact
# Set Preference to medium & run again
$ConfirmPreference='Medium'
ConfirmImpact
# Set script to 'Low' and run again
ConfirmImpact




############################################## Positional Binding

# Without Positional Binding
function Demo-NoPositionalBinding{
    [CmdletBinding(PositionalBinding=$false)]
    [Alias('NoPositionalBinding')]
    Param(
        # Param One Description
        [Parameter()]$ParamOne,
        # Param Two Description 
        [Parameter()]$ParamTwo
        )
    $PSBoundParameters
    }

# Error
NoPositionalBinding ValueOne ValueTwo


# If not explicitly declared false, Positional binding is true
function Demo-PositionalBinding{
    [CmdletBinding()]
    [Alias('PositionalBinding')]
    Param(
        # Param One Description
        [Parameter()]$ParamOne,
        # Param Two Description 
        [Parameter()]$ParamTwo
        )
    $PSBoundParameters
    }

# Ok
PositionalBinding ValueOne ValueTwo


# Set binding Attribute to false and declare Position Parameter Attribure 
# for strict explicit positional params
function Demo-PositionalBinding{
    [CmdletBinding(PositionalBinding=$false)]
    [Alias('PositionalBinding')]
    Param(
        # Param One Description
        [Parameter()]$ParamOne,
        # Param Two Description 
        [Parameter(Position=0)]$ParamTwo
        )
    $PSBoundParameters
    }

# Ok
PositionalBinding -ParamOne One -ParamTwo Two
PositionalBinding -ParamOne One Two
PositionalBinding Two -ParamOne One
# Error
PositionalBinding One Two
PositionalBinding One -ParamTwo Two



############################################## More Info
Help about_Functions_CmdletBindingAttribute

#endregion


##############################################################################
#region #### Parameter validation

############################################## ValidateSet
function Demo-ValidateSet{
    [Alias('ValidateSet')]
    Param(
        [ValidateSet('ChoiceA','ChoiceB','ChoiceC')]
        [Parameter(Mandatory=$true)][String]$Param
        )
    $PSBoundParameters
    }

# Ok (+TabComplete)
ValidateSet -Param ChoiceB
# Error
validateSet -Param SomethingElse


############################################## ValidateLength
function Demo-ValidateLength{
    [Alias('ValidateLength')]
    Param(
        [ValidateLength(5,15)]
        [Parameter(Mandatory=$true)][String]$Param
        )
    $PSBoundParameters
    }

# Ok
ValidateLength -Param 'Schwifty'
# Error 
ValidateLength -Param 'WuubbaLubbaDubDub'



############################################## ValidateCount
function Demo-ValidateCount{
    [Alias('ValidateCount')]
    Param(
        [ValidateCount(1,2)]
        [Parameter(Mandatory=$true)][String[]]$Param
        )
    $PSBoundParameters
    }

# OK
ValidateCount -Param Hello
ValidateCount -Param Hello,World
# Error
ValidateCount -Param Hello,More,World



############################################## ValidateRange
function Demo-ValidateRange{
    [Alias('ValidateRange')]
    Param(
        [ValidateRange(0,100)]
        [Parameter(Mandatory=$true)][int]$Param
        )
    $PSBoundParameters
    }

# Ok
ValidateRange -Param 77
# Error
ValidateRange -Param 123



############################################## ValidatePattern
function Demo-ValidatePattern{
    [Alias('ValidatePattern')]
    Param(
        [ValidatePattern(".+\d")]
        [Parameter(Mandatory=$true)][String]$Param
        )
    $PSBoundParameters
    }

# Ok
ValidatePattern -Param 'Hello1'
ValidatePattern -Param 'World2'
# Error
ValidatePattern -Param 'Hello'




############################################## ValidateScript
function Demo-ValidateScript{
    [Alias('ValidateScript')]
    Param(
        [ValidateScript({[Bool]$_ -eq $false})]
        [Parameter(Mandatory=$true)]$Param
        )
    $PSBoundParameters
    }

# Error
ValidateScript -Param Bob
ValidateScript -Param 1
ValidateScript -Param $true

# Ok
ValidateScript -Param 0
ValidateScript -Param $false


# Example: Path
function Demo-IsValidPath{
    [Alias('IsValidPath')]
    Param(
        [ValidateScript({Test-Path $_})]
        [Parameter()][String]$Path
        )
    Return $true
    }

# Error
IsValidPath 'invalid/Path'
#Ok
IsValidPath $pwd




############################################## ValidateNotNull
function Demo-ValidateNotNull{
    [Alias('NotNull')]
    Param(
        [ValidateNotNull()]
        [Parameter(Mandatory=$true)][String]$Param
        )
    $PSBoundParameters
    }

# Error
NotNull -Param $Null
NotNull -Param ''
# Ok
NotNull -Param 'String'


############################################## ValidateNotNullOrEmpty
function Demo-ValidateNotNullOrEmpty{
    [Alias('NotNullOrEmpty')]
    Param(
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory=$true)][Array]$Param
        )
    $PSBoundParameters
    }

# Error
NotNullOrEmpty -Param $Null
NotNullOrEmpty -Param @()
NotNullOrEmpty -Param '',''
NotNullOrEmpty -Param 'A',''
# Ok
NotNullOrEmpty -Param 'A','B'


############################################## AllowNull
function Demo-AllowNull{
    [Alias('AllowNull')]
    Param(
        [AllowNull()]
        [Parameter(Mandatory=$true)][Int]$Param
        )
    $PSBoundParameters
    }

AllowNull -Param $Null



############################################## AllowEmptyString
function Demo-AllowEmptyString{
    [Alias('AllowEmptyString')]
    Param(
        [AllowEmptyString()]
        [Parameter(Mandatory=$true)][String]$Param
        )
    $PSBoundParameters
    }

AllowEmptyString -Param '' 



############################################## AllowEmptyCollection
function Demo-AllowEmptyCollection{
    [Alias('AllowEmptyCollection')]
    Param(
        [AllowEmptyCollection()]
        [Parameter(Mandatory=$true)][Array]$Param
        )
    $PSBoundParameters
    }

# Ok
AllowEmptyCollection -Param @()
# Error
AllowEmptyCollection -Param $Null


# Note: Possible to Combine 
function Demo-MultipleValidation{
    [Alias('MultipleValidation')]
    Param(
        [ValidatePattern(".+\d")]
        [ValidateCount(1,2)]
        [ValidateLength(5,10)]
        [Parameter(Mandatory=$true)][String[]]$Param
        )
    $PSBoundParameters   
    }

# Ok  
MultipleValidation 'Hello1'
MultipleValidation 'Hello1','World2'
# Error
# Pattern
MultipleValidation 'Hello1','World'
# Length
MultipleValidation 'Hello1','W2'
# Count
MultipleValidation 'Hello1','World2','Hello3'


#endregion


##############################################################################
#region #### Value From Pipeline & Remaining



############################################## ValueFromPipeline A - Single/Error
function Demo-ValueFromPipelineA{
    [Alias('PipeA')]
    param(
        [parameter(ValueFromPipeline=$true)][Int]$Number
        )
    "Number is $Number"
    }

# Ok
7 | PipeA
# also without pipe
PipeA -Number 7
# Unwanted results
1,2,3 | PipeA
PipeA 1,2,3

  


############################################## ValueFromPipeline B - Process
function Demo-ValueFromPipelineB{
    [Alias('PipeB')]
    param(
        [parameter(ValueFromPipeline=$true)][Int]$Number
        )
    Process{"Number is $Number"}
    }

# Multiple over Pipeline OK
1,2,3 | PipeB
# Error
PipeB 1,2,3



############################################## ValueFromPipeline C - Begin&End
function Demo-ValueFromPipelineC{
    [Alias('PipeC')]
    param(
        [parameter(ValueFromPipeline=$true)][Int]$Number
        )
    Begin{'This Happens Before First Pipeline Input'}
    Process{"Number is $Number"}
    End{'This Happens After Last Pipeline Input'}
    }

# Really Cool
1,2,3 | PipeC

# ... but still Error
PipeC 1,2,3





############################################## ValueFromPipeline D - All Good
function Demo-ValueFromPipelineD{
    [Alias('PipeD')]
    param(
        [parameter(ValueFromPipeline=$true)][Int[]]$Number
        )
    Begin{'Begin'}
    Process{
        foreach($Num in $Number){"Number is $Num"}
        }
    End{'End'}
    }

# All Good 
1,2,3 | PipeD
PipeD 1,2,3








############################################## ValueFromPipelineByPropertyName
# -> Catch multiple prop values from object over pipeline
function Demo-ValueFromPipelineByPropertyName{
    [Alias('PipePropName')]
    param(
        [parameter(ValueFromPipelineByPropertyName=$true)][Int]$Hour,
        [parameter(ValueFromPipelineByPropertyName=$true)][Int]$Minute,
        [parameter(ValueFromPipelineByPropertyName=$true)][Int]$Second
        )
    "It is ${Hour}h${Minute}m${Second}s"
    }

# Ok
Get-Date | PipePropName
# Error
10 | PipePropName





############################################## Remaining Arguments & DontShow
function Demo-RemainingArgs{
    [Alias('RemainingArgs')]
    param(
        [parameter()][String]$ParamOne,
        [parameter(ValueFromRemainingArguments=$true,DontShow)]$AllTheRest
        )
    $AllTheRest
    }

# Can be cool
RemainingArgs -ParamOne HelloWorld -Watever IWant -AndMore 1,2,3
# /!\ Danger
RemainingArgs -ParamOne HelloWorld -AndMore 1,2,3 -AndMore -AndMore 


## Look Mama!
function Demo-NoQuoteString{
    [Alias('NoQuote')]
    param(
        [parameter(ValueFromRemainingArguments=$true,DontShow)][String]$WhateverString
        )
    $WhateverString -join ' '
    }

# No Quotes
NoQuote Look Mama! No Quotes!!



#endregion


##############################################################################
#region #### Parameter Sets

# GRAPH <--------------------------------------------- Back To Slides...


# EXAMPLES


############################################## Invoke-Example1

<#
.Synopsis
   ParamSet Example 1
.DESCRIPTION
   Long Description
.EXAMPLE
   Invoke-Example1
   Example Description
#>
Function Invoke-Example1{
    [CmdletBinding(HelpUri='http://this/is/example1')]
	[Alias('Example1')]
    Param(
		# Example1 Like This
		[Parameter(Mandatory=$True,ParameterSetName='LikeThis')][switch]$LikeThis,
		# Example1 Like So
		[Parameter(Mandatory=$True,ParameterSetName='LikeSo')][switch]$LikeSo,
		# Example1 Like That
		[Parameter(Mandatory=$True,ParameterSetName='LikeThat')][switch]$LikeThat,
		# With this or that?
		[ValidateSet('This','That')]
		[Parameter(Mandatory=$True,ParameterSetName='LikeThis')]
		[Parameter(Mandatory=$True,ParameterSetName='LikeSo')]
		[Parameter(Mandatory=$True,ParameterSetName='LikeThat')][string]$With,
		# Option switch MakeItSo
		[Parameter(Mandatory=$False,ParameterSetName='LikeThis')]
		[Parameter(Mandatory=$False,ParameterSetName='LikeSo')]
		[Parameter(Mandatory=$False,ParameterSetName='LikeThat')][switch]$MakeItSo
		)
    # Make It So
    <# Code Goes Here #>
    # Return Result
    Return $Result
    }

# Ok (Tab) 
Invoke-Example1  <#DASH#>
# Syntax (=ParamSets)
(Help Invoke-Example1).syntax 


############################################## Invoke-Example2

<#
.Synopsis
   ParamSet Example 2
.DESCRIPTION
   Long Description
.EXAMPLE
   Invoke-Example2
   Example Description
#>
Function Invoke-Example2{
    [CmdletBinding(HelpUri='http://this/is/example2')]
	[Alias('Example2')]
    Param(
		# Example2 Like This
		[Parameter(Mandatory=$True,ParameterSetName='LikeThisWithThis')]
		[Parameter(Mandatory=$True,ParameterSetName='LikeThisWithThat')][switch]$LikeThis,
		# Example2 Like That
		[Parameter(Mandatory=$True,ParameterSetName='LikeThatWithThis')]
		[Parameter(Mandatory=$True,ParameterSetName='LikeThatWithThat')][switch]$LikeThat,
		# Example2 With This
		[Parameter(Mandatory=$True,ParameterSetName='LikeThisWithThis')]
		[Parameter(Mandatory=$True,ParameterSetName='LikeThatWithThis')][switch]$WithThis,
		# Example2 With That
		[Parameter(Mandatory=$True,ParameterSetName='LikeThisWithThat')]
		[Parameter(Mandatory=$True,ParameterSetName='LikeThatWithThat')][switch]$WithThat,
		# Option switch MakeItSo if LikeThis
		[Parameter(Mandatory=$False,ParameterSetName='LikeThisWithThis')]
		[Parameter(Mandatory=$False,ParameterSetName='LikeThisWithThat')][switch]$MakeItSo
		)
    # Make It So
    <# Code Goes Here #>
    # Return Result
    Return $Result
    }

# Ok (Tab) 
Invoke-Example2  <#DASH#>
# Syntax (=ParamSets)
(Help Invoke-Example2).syntax 

############################################## /!\ Limit Max 32

<#
.Synopsis
   Synopsis
.DESCRIPTION
   Long Description 
.EXAMPLE
   Example
#>
function Demo-ParamSetLimit{
    [CmdletBinding(DefaultParameterSetName='01')]
    [Alias('ParamSetLimit')]
    Param(
        [Parameter(Mandatory=$false,ParameterSetName='01')][Switch]$Set01,
        [Parameter(Mandatory=$true,ParameterSetName='02')][Switch]$Set02,
        [Parameter(Mandatory=$true,ParameterSetName='03')][Switch]$Set03,
        [Parameter(Mandatory=$true,ParameterSetName='04')][Switch]$Set04,
        [Parameter(Mandatory=$true,ParameterSetName='05')][Switch]$Set05,
        [Parameter(Mandatory=$true,ParameterSetName='06')][Switch]$Set06,
        [Parameter(Mandatory=$true,ParameterSetName='07')][Switch]$Set07,
        [Parameter(Mandatory=$true,ParameterSetName='08')][Switch]$Set08,
        [Parameter(Mandatory=$true,ParameterSetName='09')][Switch]$Set09,
        [Parameter(Mandatory=$true,ParameterSetName='10')][Switch]$Set10,
        [Parameter(Mandatory=$true,ParameterSetName='11')][Switch]$Set11,
        [Parameter(Mandatory=$true,ParameterSetName='12')][Switch]$Set12,
        [Parameter(Mandatory=$true,ParameterSetName='13')][Switch]$Set13,
        [Parameter(Mandatory=$true,ParameterSetName='14')][Switch]$Set14,
        [Parameter(Mandatory=$true,ParameterSetName='15')][Switch]$Set15,
        [Parameter(Mandatory=$true,ParameterSetName='16')][Switch]$Set16,
        [Parameter(Mandatory=$true,ParameterSetName='17')][Switch]$Set17,
        [Parameter(Mandatory=$true,ParameterSetName='18')][Switch]$Set18,
        [Parameter(Mandatory=$true,ParameterSetName='19')][Switch]$Set19,
        [Parameter(Mandatory=$true,ParameterSetName='20')][Switch]$Set20,
        [Parameter(Mandatory=$true,ParameterSetName='21')][Switch]$Set21,
        [Parameter(Mandatory=$true,ParameterSetName='22')][Switch]$Set22,
        [Parameter(Mandatory=$true,ParameterSetName='23')][Switch]$Set23,
        [Parameter(Mandatory=$true,ParameterSetName='24')][Switch]$Set24,
        [Parameter(Mandatory=$true,ParameterSetName='25')][Switch]$Set25,
        [Parameter(Mandatory=$true,ParameterSetName='26')][Switch]$Set26,
        [Parameter(Mandatory=$true,ParameterSetName='27')][Switch]$Set27,
        [Parameter(Mandatory=$true,ParameterSetName='28')][Switch]$Set28,
        [Parameter(Mandatory=$true,ParameterSetName='29')][Switch]$Set29,
        [Parameter(Mandatory=$true,ParameterSetName='30')][Switch]$Set30,
        [Parameter(Mandatory=$true,ParameterSetName='31')][Switch]$Set31,
        [Parameter(Mandatory=$true,ParameterSetName='32')][Switch]$Set32,
        #[Parameter(Mandatory=$true,ParameterSetName='33')][Switch]$Set33,
        # All Paramset
        [Parameter()][Switch]$Param
        )
    $PSCmdlet.ParameterSetName
    }
# Test
ParamSetLimit
ParamSetLimit -Set32
# Check syntax (don't forget F8)
(Help Demo-ParamSetLimit).syntax

# Add set00 & Test
ParamSetLimit -Set32
# Check syntax (don't forget F8)
(Help Demo-ParamSetLimit).syntax

#
#  /!\ Tip: Do not use too many ParamSets. Use Verbs > Make Smaller Cmdlets.
#


#endregion


##############################################################################
#region #### Dynamic Parameters

# Note: In many case, dynamic Parameters can be avoided by using ParameterSets

# I have found these two cases to work for me (Let me know how you use this...)
# - DynamicParam depends on value of a previous Regular Param
# - Dynamic Validation based on ParameterSet if
#   list of possible values changes during session



############################################## DynExample1
# DynamicParam depending on Param Value
function Demo-DynExample1{
    [Cmdletbinding()]
    [Alias('DynExample1')]
    Param(
        [ValidateSet('A','B')]
        [Parameter(Mandatory=$True,Position=0)][String]$ParamOne
        )
    DynamicParam{
        # Select Matching List
        Switch($ParamOne){
            'A'{$VSet=@('A1','A2','A3')}
            'B'{$VSet=@('B1','B2','B3')}
            }
        
        ## Prep Dictionnary
        $Dictionary = New-Object System.Management.Automation.RuntimeDefinedParameterDictionary
        ## Prep Dynamic Param
        # Create First Attribute Obj
        $Attrib = New-Object System.Management.Automation.ParameterAttribute
        $Attrib.Mandatory = $true
        $Attrib.Position = 1
        # Create AttributeCollection obj
        $Collection = new-object System.Collections.ObjectModel.Collection[System.Attribute]
        # Add Attribute Obj to Attibute Collection Obj
        $Collection.Add($Attrib)
        # Create Validate Set Obj & add to collection     
        $ValidateSet=new-object System.Management.Automation.ValidateSetAttribute($VSet)
        $Collection.Add($ValidateSet)
        # Create Runtine DynParam from Collection
        $DynParam = New-Object System.Management.Automation.RuntimeDefinedParameter('ParamTwo', [String], $Collection)
        # Add dynamic Param to Dictionary
        $Dictionary.Add('ParamTwo', $DynParam)
        ## Return Dictionary
        return $Dictionary 
        }
    Begin{$PSBoundParameters}
    Process{}
    End{}
    }

# Ok
DynExample1 -ParamOne A -ParamTwo <#SPACE#>
DynExample1 A A1
DynExample1 B <#TAB#>
# Error
DynExample1 -ParamOne B -ParamTwo A1


############################################## DynExample2 - FruitVeggie
# Dynamic Param depending on Changing validateSet List

# External Lists
$FruitList = @('Apple','Banana','Strawberry','Orange')
$VeggieList =  @('Tomato','Cucumber','Paprika','Courgette')

# DynExample2
function Invoke-FruitAndVeggie{
    [CmdletBinding(DefaultParameterSetName='List',PositionalBinding=$false)]
    [Alias('FruitVeggie')]
    Param(
        # List
        [ValidateSet('All','Veggie','Fruit')]
        [Parameter(Position=0,Mandatory=$false,ParameterSetName='List')][String]$List='All',
        # Select
        [ValidateSet('Veggie','Fruit')]
        [Parameter(Mandatory=$true,ParameterSetName='Select')][String]$Select,
        # Remove
        [ValidateSet('Veggie','Fruit')]
        [Parameter(Mandatory=$true,ParameterSetName='Remove')][String]$Remove,
        # Add
        [ValidateSet('Veggie','Fruit')]
        [Parameter(Mandatory=$true,ParameterSetName='Add')][String]$Add,
        [Parameter(Position=0,Mandatory=$true,ParameterSetName='Add')][String]$NewName
        )
    DynamicParam{
        # Select
        if($PSCmdlet.ParameterSetName -eq 'Select'){
            Switch($Select){
                'Veggie'{$SelectedList=$Script:VeggieList}
                'Fruit' {$SelectedList=$Script:FruitList}
                }
            }
        # Remove
        if($PSCmdlet.ParameterSetName -eq 'Remove'){
            Switch($Remove){
                'Veggie'{$SelectedList=$Script:VeggieList}
                'Fruit' {$SelectedList=$Script:FruitList}
                }
            }
        # Select or Remove 
        if($PSCmdlet.ParameterSetName -in 'Select','Remove'){
            ## Create Dynamic params
            #Prep Dictionnary obj
            $Dictionary = New-Object System.Management.Automation.RuntimeDefinedParameterDictionary        
            # Create Attribute Collection
            $Attrib = New-Object System.Management.Automation.ParameterAttribute
            $Attrib.Mandatory = $true
            $Attrib.Position = 0
            # Create AttributeCollection object for the attribute Object
            $Collection = new-object System.Collections.ObjectModel.Collection[System.Attribute]
            # Add our custom attribute
            $Collection.Add($Attrib)
            # Add Validate Set     
            $ValidateSet=new-object System.Management.Automation.ValidateSetAttribute($SelectedList)
            $Collection.Add($ValidateSet)
            # Create Runtime Parameter with matching attribute collection
            $DynParam = New-Object System.Management.Automation.RuntimeDefinedParameter('Name', [String], $Collection)        
            # Add all Runtime Params to dictionary
            $Dictionary.Add('Name', $DynParam)
            # Return Dictionary
            return $Dictionary
            } 
        }
    Begin{
        # Store ParamSetName
        $PSN = $PSCmdlet.ParameterSetName
        }
    Process{         
        ## List
        If($PSN -eq 'List'){
            # Get matching List
            Switch($List){
                'All'   {$Result=($Script:VeggieList+$Script:fruitList)}
                'Veggie'{$Result=$Script:VeggieList}
                'Fruit' {$Result=$Script:fruitList}
                }
            }
        
        ## Select
        If($PSN -eq 'Select'){$Result = "You Have Selected "+$DynParam.Value}        
        ## Add
        If($PSN -eq 'Add'){
            Switch($Add){
                # Add to fruit
                'Fruit' {$Script:FruitList  += $NewName; $result=$Script:FruitList}
                # Add to Veggie
                'Veggie'{$Script:VeggieList += $NewName; $result=$Script:VeggieList}
                }
            }       
        ## Remove
        If($PSN -eq 'Remove'){
            Switch($Remove){
                # Remove From Fruit
                'Fruit' {$Script:FruitList  = $Script:FruitList  -ne $DynParam.Value; $result=$Script:FruitList}
                # Remove efrom Veggie
                'Veggie'{$Script:VeggieList = $Script:VeggieList -ne $DynParam.Value; $result=$Script:VeggieList}
                }
            }       
        }
    # Return Result
    End{return $result}
    }

# List
FruitVeggie -List All
FruitVeggie
FruitVeggie -List Fruit
FruitVeggie Veggie
# Select (TabCompletion)
FruitVeggie -Select Fruit - <#DASH|TAB|SPACE#>
# Add
FruitVeggie -Add Fruit -NewName Apricot
FruitVeggie -Add Fruit Peach
# Select (TabCompletion)
FruitVeggie -Select Fruit -Name <#TAB|SPACE#>
FruitVeggie -Select Fruit Courgette
# Remove
FruitVeggie -Remove Fruit -Name   <#TAB|SPACE#>
FruitVeggie -Remove Fruit   <#TAB#>

# <-------------------------------------------------------- Back To Slides...

#endregion


########################################################################## EOF



