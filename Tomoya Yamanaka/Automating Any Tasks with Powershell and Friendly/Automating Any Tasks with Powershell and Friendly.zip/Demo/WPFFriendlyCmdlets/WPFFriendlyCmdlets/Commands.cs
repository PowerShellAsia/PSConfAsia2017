﻿using System.Diagnostics;
using System.Linq;
using System.Management.Automation;
using Codeer.Friendly.Windows;
using RM.Friendly.WPFStandardControls;
using Codeer.Friendly.Windows.Grasp;
using System.Windows.Controls;
using System;
using Codeer.Friendly.Dynamic;
using Codeer.Friendly;

namespace WPFFriendlyCmdlets
{
    [Cmdlet(VerbsCommon.Get, "WpfText")]
    public class WpfGedtTextCommand : Cmdlet
    {
        [Parameter(Mandatory = true, ValueFromPipeline = true, Position = 0)]
        public Process Process { get; set; }

        [Parameter(Mandatory = false, ValueFromPipeline = false, Position = 1)]
        public string Binding { get; set; }

        protected override void ProcessRecord()
        {
            var _app = new WindowsAppFriend(this.Process);
            var windows = WindowControl.GetTopLevelWindows(_app);
            var textBox = new WPFTextBox(windows.Select(e => e.LogicalTree().ByType<TextBox>().ByBinding(Binding)).Where(e => e.Count == 1).Single().Single());
            WriteObject(textBox.Text);
        }
    }

    [Cmdlet(VerbsCommon.Set, "WpfText")]
    public class WpfEditTextCommand : Cmdlet
    {
        [Parameter(Mandatory = true, ValueFromPipeline = true, Position = 0)]
        public Process Process { get; set; }

        [Parameter(Mandatory = false, ValueFromPipeline = false, Position = 1)]
        public string Binding { get; set; }

        [Parameter(Mandatory = false, ValueFromPipeline = false, Position = 2)]
        public string Text { get; set; }

        protected override void ProcessRecord()
        {
            var _app = new WindowsAppFriend(this.Process);
            var windows = WindowControl.GetTopLevelWindows(_app);
            var textBox = new WPFTextBox(windows.Select(e => e.LogicalTree().ByType<TextBox>().ByBinding(Binding)).Where(e => e.Count == 1).Single().Single());
            textBox.EmulateChangeText(Text);
        }
    }
    
    [Cmdlet(VerbsCommon.Set, "WpfCombo")]
    public class WpfEditComboCommand : Cmdlet
    {
        [Parameter(Mandatory = true, ValueFromPipeline = true, Position = 0)]
        public Process Process { get; set; }

        [Parameter(Mandatory = false, ValueFromPipeline = false, Position = 1)]
        public string Binding { get; set; }

        [Parameter(Mandatory = false, ValueFromPipeline = false, Position = 2)]
        public int Index { get; set; }

        protected override void ProcessRecord()
        {
            var _app = new WindowsAppFriend(this.Process);
            var windows = WindowControl.GetTopLevelWindows(_app);
            var combo = new WPFComboBox(windows.Select(e => e.LogicalTree().ByType<ComboBox>().ByBinding(Binding)).Where(e => e.Count == 1).Single().Single());
            combo.EmulateChangeSelectedIndex(Index);
        }
    }

    [Cmdlet(VerbsCommon.Set, "WpfRadio")]
    public class WpfEditRadioCommand : Cmdlet
    {
        [Parameter(Mandatory = true, ValueFromPipeline = true, Position = 0)]
        public Process Process { get; set; }

        [Parameter(Mandatory = false, ValueFromPipeline = false, Position = 1)]
        public string Binding { get; set; }

        protected override void ProcessRecord()
        {
            var _app = new WindowsAppFriend(this.Process);
            var windows = WindowControl.GetTopLevelWindows(_app);
            var radio = new WPFToggleButton(windows.Select(e => e.LogicalTree().ByType<RadioButton>().ByBinding(Binding)).Where(e => e.Count == 1).Single().Single());
            radio.EmulateCheck(true);
        }
    }
    
    [Cmdlet(VerbsCommon.Set, "WpfCalendar")]
    public class WpfEditCalendarCommand : Cmdlet
    {
        [Parameter(Mandatory = true, ValueFromPipeline = true, Position = 0)]
        public Process Process { get; set; }

        [Parameter(Mandatory = false, ValueFromPipeline = false, Position = 1)]
        public string Binding { get; set; }

        [Parameter(Mandatory = false, ValueFromPipeline = false, Position = 2)]
        public DateTime Date { get; set; }

        protected override void ProcessRecord()
        {
            var _app = new WindowsAppFriend(this.Process);
            var windows = WindowControl.GetTopLevelWindows(_app);
            var calendar = new WPFCalendar(windows.Select(e => e.LogicalTree().ByType<Calendar>().ByBinding(Binding)).Where(e => e.Count == 1).Single().Single());
            calendar.EmulateChangeDate(Date);
        }
    }
    
    [Cmdlet(VerbsCommon.Set, "WpfButton")]
    public class WpfClickButtonCommand : Cmdlet
    {
        [Parameter(Mandatory = true, ValueFromPipeline = true, Position = 0)]
        public Process Process { get; set; }

        [Parameter(Mandatory = false, ValueFromPipeline = false, Position = 1)]
        public string Content { get; set; }

        protected override void ProcessRecord()
        {
            var _app = new WindowsAppFriend(this.Process);
            var windows = WindowControl.GetTopLevelWindows(_app);
            var buttons = windows.Select(e => e.LogicalTree().ByType<Button>()).ToArray();
            AppVar button = null;
            for (int i = 0; i < buttons.Length; i++)
            {
                var count = buttons[i].Count;
                for (int j = 0; j < count; j++)
                {
                    try
                    {
                        string text = buttons[i][j].Dynamic().Content;
                        if (text == Content)
                        {
                            button = buttons[i][j];
                            break;
                        }
                    }
                    catch { }
                }
            }
            if (button != null)
            {
                new WPFButtonBase(button).EmulateClick();
            }
        }
    }

    [Cmdlet(VerbsCommon.Set, "WpfTab")]
    public class WpfEditTabCommand : Cmdlet
    {
        [Parameter(Mandatory = true, ValueFromPipeline = true, Position = 0)]
        public Process Process { get; set; }

        [Parameter(Mandatory = false, ValueFromPipeline = false, Position = 1)]
        public int LogicalIndex { get; set; }

        [Parameter(Mandatory = false, ValueFromPipeline = false, Position = 2)]
        public int Index { get; set; }

        protected override void ProcessRecord()
        {
            var _app = new WindowsAppFriend(this.Process);
            var windows = WindowControl.GetTopLevelWindows(_app);

            var tabs = windows.Select(e => e.LogicalTree().ByType<TabControl>()).Where(e => e.Count == 1).ToArray();

            AppVar tab = null;
            int index = 0;
            for (int i = 0; i < tabs.Length; i++)
            {
                var count = tabs[i].Count;
                for (int j = 0; j < count; j++, index++)
                {
                    if (index == LogicalIndex)
                    {
                        tab = tabs[i][j];
                        break;
                    }
                }
            }
            if (tab != null)
            {
                new WPFTabControl(tab).EmulateChangeSelectedIndex(Index);
            }
        }
    }
}
