#initialize
Import-Module ".\WPFFriendlyCmdlets\WPFFriendlyCmdlets\bin\Release\WPFFriendlyCmdlets.dll"
$ps = Get-Process WpfApplication
$p = $ps[0]

#data 1
Set-WpfTab -Process $p -LogicalIndex 0 -Index 0
Set-WpfText -Process $p -Binding Name.Value "Tatsuya Ishikawa"
Set-WpfText -Process $p -Binding Mail.Value "abc@xyz"
Set-WpfCombo -Process $p -Binding Language.Value -Index 2
Set-WpfRadio -Process $p -Binding IsMan.Value
Set-WpfCalendar -Process $p -Binding BirthDay.Value 1977/01/07
Set-WpfButton -Process $p -Content Register
Set-WpfTab -Process $p -LogicalIndex 0 -Index 1

#data 2
Set-WpfTab -Process $p -LogicalIndex 0 -Index 0
Set-WpfText -Process $p -Binding Name.Value "Hanako Yamada"
Set-WpfText -Process $p -Binding Mail.Value "efg@xyz"
Set-WpfCombo -Process $p -Binding Language.Value -Index 1
Set-WpfRadio -Process $p -Binding IsWoman.Value
Set-WpfCalendar -Process $p -Binding BirthDay.Value 1999/08/08
Set-WpfButton -Process $p -Content Register
Set-WpfTab -Process $p -LogicalIndex 0 -Index 1