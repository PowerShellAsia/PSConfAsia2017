﻿using System.Windows.Controls;

namespace WpfApplication
{
    public partial class ViewControl : UserControl
    {
        public ViewControl()
        {
            InitializeComponent();
        }
    }
}
