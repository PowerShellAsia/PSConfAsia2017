﻿using System.Windows;

namespace WpfApplication
{
    public partial class App : Application { }
}
