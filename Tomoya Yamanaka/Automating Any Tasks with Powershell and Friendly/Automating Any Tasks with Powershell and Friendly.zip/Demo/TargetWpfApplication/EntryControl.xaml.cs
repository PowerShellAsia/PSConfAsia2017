﻿using System.Windows.Controls;

namespace WpfApplication
{
    public partial class EntryControl : UserControl
    {
        public EntryControl()
        {
            InitializeComponent();
        }
    }
}
