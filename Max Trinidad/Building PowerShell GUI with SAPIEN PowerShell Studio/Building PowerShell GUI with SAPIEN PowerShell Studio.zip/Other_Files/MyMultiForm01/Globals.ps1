﻿#--------------------------------------------
# Declare Global Variables and Functions here
#--------------------------------------------

#Sample function that provides the location of the script
function Get-ScriptDirectory
{
<#
	.SYNOPSIS
		Get-ScriptDirectory returns the proper location of the script.

	.OUTPUTS
		System.String
	
	.NOTES
		Returns the correct path within a packaged executable.
#>
	[OutputType([string])]
	param ()
	if ($null -ne $hostinvocation)
	{
		Split-Path $hostinvocation.MyCommand.path
	}
	else
	{
		Split-Path $script:MyInvocation.MyCommand.Path
	}
}

#Sample variable that provides the location of the script
[string]$ScriptDirectory = Get-ScriptDirectory


function Get-SQLSPWho2
{
	## - Default connection:
	$global:SqlSrvName = 'sapien01,1451';
	$global:con = "server=$($global:SqlSrvName);database=Master;Integrated Security=false;Connection Timeout=21600;User ID=sa;" + 'Password=$SqlPwd01!';
	
	try
	{
		$sda = New-Object System.Data.SqlClient.SqlDataAdapter ('Sp_who2', $global:con);
		$sdt = New-Object System.Data.DataTable;
		$sda.TableMappings.Add("Table", "MyLocalWho2Monitor");
		$sda.fill($sdt) | Out-Null;
		$datagrid1.DataSource = $sdt ;
	}
	catch
	{
		Show-MsgBox -Caption "SQL Server Connection Exception" -TextMsg "Error connecting to SQL Server: `r`n$($error[0])";
	}
	
};

function Show-MsgBox
{
<# 
.SYNOPSIS
    Display a Windows Messagebox. 
.Description 
    This function will allow you to prompt both a simple and a Yes/No message box.  This function can be use in both
    PowerShell V1 and V2. Has the alias - smb.
.Parameter TextMsg 
    TextMsg - [String].  This is your text message to be display in the box. (Required)
.Parameter Caption
    Caption - [String].  This is your messagebox Title. (Optional)
.Parameter YesNo
    YesNo - [String].  Use a "Y" to enable Yes/No buttons to show. (Optional)
.Example 
    PS> Show-MsgBox "Hello Everyone" "Test Tile" "Y"
    Using the full function name with all paramaters
.Example
    PS> smb "Hello Everyone" "Test Tile" "Y"
    Using the alias function with all paramters
.Example    
    PS> smb "Wait here!"
    Function in its simple form
.Notes 
	NAME: Show-MsgBox
	Alias: smb	
	AUTHOR: Max Trinidad	 
	Created:  04/16/2010 21:16:01 
	Compatibility - Version 1 and Version 2
.Link 
    about_functions 
    about_functions_advanced 
    about_functions_advanced_methods 
    about_functions_advanced_parameters 
.Inputs
	TextMsg - [String] - Required
	Caption - [String] - Optional
	YesNo - [String] Need to be "Y". - Optional
.Outputs
	Retun [String] - Only if YesNo Parameter is used.
#>	
	
	Param ([string]$TextMsg,
		[string]$Caption,
		[string]$YesNo)
	
	[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") | Out-Null;
	
	if ($caption -eq $null) { $caption = "msgbox caption" }
	
	if ($YesNo.ToUpper() -eq "Y")
	{
		$result = [System.Windows.Forms.MessageBox]::Show($textMsg, $caption, [System.Windows.Forms.MessageBoxButtons]::YesNo);
		return $result
	}
	else
	{
		$result = [System.Windows.Forms.MessageBox]::Show($TextMsg, $caption);
	};
};