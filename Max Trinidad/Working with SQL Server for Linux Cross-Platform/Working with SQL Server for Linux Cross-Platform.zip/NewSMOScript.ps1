# Build path to misc assemblies (SMO, SqlClient, ...)
#$sqlclientpath = Join-Path ((Get-Package System.Data.SqlClient).Source  | Split-Path) (Join-Path lib netstandard2.0)
$smopath = Join-Path ((Get-Package Microsoft.SqlServer.SqlManagementObjects).Source `
| Split-Path) (Join-Path lib netcoreapp2.0);

# Add types …:
# Add-Type -Path (Join-Path $sqlclientpath System.Data.SqlClient.dll)
Add-Type -Path (Join-Path $smopath Microsoft.SqlServer.Smo.dll)
Add-Type -Path (Join-Path $smopath Microsoft.SqlServer.ConnectionInfo.dll)

## - Prepare connection strings and connect to SQL Serv
$SQLServerInstanceName = 'sapien01,1450'; $SQLUserName = 'sa'; $sqlPwd = '$SqlPwd01!';

## - Prepare connection to SQL Server:
$SQLSrvConn = new-object Microsoft.SqlServer.Management.Common.SqlConnectionInfo($SQLServerInstanceName, $SQLUserName, $SqlPwd);
$SQLSrvObj = new-object Microsoft.SqlServer.Management.Smo.Server($SQLSrvConn);

## - SMO Get SQL Server Info:
$SQLSrvObj.Information `
| Select-Object parent, platform, product, productlevel, `
	              OSVersion, Edition, version, HostPlatform, HostDistribution `
| Format-List;
