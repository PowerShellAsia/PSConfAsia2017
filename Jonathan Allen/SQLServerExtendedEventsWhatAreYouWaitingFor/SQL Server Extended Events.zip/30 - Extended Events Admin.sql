--	SQL Server Extended Events

use msdb
go

SELECT *
FROM sys.server_event_sessions
go

SELECT *
FROM sys.ser

USE XE_Demo
go
SELECT *
FROM sys.event_sessions;
go

use tempdb
go
