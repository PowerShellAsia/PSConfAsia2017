--	SQL Server Extended Events
USE XE_Demo
GO

-- make sure the Event Session is running

BEGIN TRY
	ALTER EVENT SESSION [XEDemo_SlowProc]
		ON SERVER
	STATE=START;
END TRY
BEGIN CATCH
	
END CATCH
go


USE XE_Demo
GO

EXEC usp_SlowProc01 @rows = 50;
go


EXEC usp_SlowProc01 @rows = 50;
EXEC usp_SlowProc01 @rows = 5;
EXEC usp_SlowProc01 @rows = 250;
go


EXEC usp_SlowProc01 @rows = 50;
EXEC usp_SlowProc01 @rows = 5;
EXEC usp_SlowProc01 @rows = 500;
EXEC usp_SlowProc01 @rows = 250;
EXEC usp_SlowProc01 @rows = 5000;
EXEC usp_SlowProc01 @rows = 890;
go

use tempdb
go
