-- SQL Server Extended Events
-- Create [XE_Deprecated_Events] extended event session
CREATE EVENT SESSION [XE_Deprecated_Events] ON SERVER 

ADD EVENT sqlserver.deprecation_announcement( -- STOP USING THESE FEATURES IN NEW WORK AND PLAN TO MOVE AWAY ASAP
    ACTION(
		sqlserver.client_app_name,
		sqlserver.sql_text,
		sqlserver.username)),

ADD EVENT sqlserver.deprecation_final_support( -- THESE FEATURES WILL NOT BE IN THE NEXT VERSION OF SQL SERVER. THIS WILL PREVENT YOU UPGRADING
    ACTION(
		sqlserver.client_app_name,
		sqlserver.sql_text,
		sqlserver.username))

ADD TARGET package0.event_file(
	SET filename=N'Deprecated_Events')

WITH (
	MAX_MEMORY=4096 KB,
	EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,
	MAX_DISPATCH_LATENCY=30 SECONDS,
	MAX_EVENT_SIZE=0 KB,
	MEMORY_PARTITION_MODE=NONE,
	TRACK_CAUSALITY=OFF,
	STARTUP_STATE=OFF)
GO


