--	SQL Server Extended Events
--	Create [XEDemo_SlowProc] extended event session
use master
go

-- Capturing slow running queries on this server
CREATE EVENT SESSION [XEDemo_SlowProc] 
	ON SERVER 
-- Any SQL Stored Procedure taking longer than 2s
ADD EVENT sqlserver.sp_statement_completed(
	SET collect_statement=(1)
    ACTION(
		sqlserver.client_app_name,
		sqlserver.database_name,
		sqlserver.sql_text,
		sqlserver.username)
    WHERE ([duration]>=(2000000))),
-- Any SQL Batch taking longer than 2s
ADD EVENT sqlserver.sql_batch_completed(
    ACTION(sqlserver.client_app_name,sqlserver.database_name,sqlserver.nt_username,sqlserver.sql_text)
    WHERE ([duration]>=(2000000))),	
-- Any SQL Statement taking longer than 2s
ADD EVENT sqlserver.sql_statement_completed(
    ACTION(sqlserver.client_app_name,sqlserver.database_name,sqlserver.nt_username,sqlserver.sql_text)
    WHERE ([duration]>=(2000000)))
--	Collected information will be stored on disk
ADD TARGET package0.event_file(
	SET filename=N'XEDemo_SlowProc',
	max_file_size=(10))
-- Session resources
WITH (
	MAX_MEMORY=4096 KB,
	EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,
	MAX_DISPATCH_LATENCY=3 SECONDS,
	MAX_EVENT_SIZE=0 KB,
	MEMORY_PARTITION_MODE=NONE,
	TRACK_CAUSALITY=OFF,
	STARTUP_STATE=OFF)
GO


use tempdb
go

