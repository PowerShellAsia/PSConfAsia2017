--	SQL Server Extended Events
USE master
go

select db_id()

-- create our own database for demos
CREATE DATABASE XE_Demo
GO

USE XE_Demo
GO

-- create table and some dummy data for the queries to run against
CREATE TABLE XEData (ID INT, CxName varchar(100), CxID varchar(10))
GO

DROP TABLE IF EXISTS #digits
GO

CREATE TABLE #digits (d INT)
GO

INSERT #digits
VALUES(0),(1),(2),(3),(4),(5),(6),(7),(8),(9)
GO

INSERT XEData (ID, CxName)
Select d1.d + d2.d*10 + d3.d*100 + d4.d*1000 as ID,
REPLICATE('A', ABS(CHECKSUM(NEWID()))% 100) as CxName
from #digits as d1
, #digits as d2
, #digits as d3
, #digits as d4;
GO
-- SELECT TOP 200 * FROM XEData -- test the data is there

-- Create a procedure that will simulate a slow running query
CREATE OR ALTER PROC usp_SlowProc01 (@rows INT)
as
SELECT TOP (@rows )
	d.ID, cxname 
FROM XEData as d;

WAITFOR DELAY '00:00:00.8'; -- we make it artificially slow with a WAITFOR DELAY command
GO


USE tempdb
GO